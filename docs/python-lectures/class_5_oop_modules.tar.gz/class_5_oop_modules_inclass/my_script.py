# Copyright (C) 2023 Maxim Fedotov <maxim.fedotov@upf.edu>

# This script is just to remind you how to make a part of code to be
# run and produce an output when executed from a CLI.
# Prioritize writing tests to check correctness of routines that you
# develop.

from pycars.main import *
from pycars.utils import *

# This part of code runs when we execute the script through a CLI.
if __name__ == '__main__':
    convertible = Convertible(
        model='Fancy Car', 
        color='pink', 
        horse_power=300, 
        roof_state='up'
    )
    convertible.move('left', 1)
    print(convertible.roof_state, convertible.location)
    # MeasureConverter.convertable_to("hp")
    # car = Car('pink', 88)
    # car.drive('left', 1)
    # print(car.location)