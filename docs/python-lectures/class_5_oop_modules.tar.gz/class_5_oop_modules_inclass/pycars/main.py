# Copyright (C) 2023 Maxim Fedotov <maxim.fedotov@upf.edu>

from numbers import Number 
from typing import Literal


class Car:
    
    allowed_directions = ["left", "right"]
    
    def __init__(
        self,
        model: str,
        color: str,
        horse_power: int,
        location: Number = 0
    ) -> None:
        self.model = model
        self.color = color
        self.horse_power = horse_power
        self.location = location
        
    def move(
        self, 
        direction: Literal["left", "right"],
        by: Number
    ) -> None:
        if direction not in self.allowed_directions:
            raise ValueError(
                "Direction must be either "
                + " or ".join(self.allowed_directions) + "."
            )
        self.location += (2 * (direction == "right") - 1) * by

# Let's add a class that inherits properties and methods from the Car class.
# You can check that method .move works as well for an instance of 
# class Convertible as it is inherited from Car.

class Convertible(Car):
    
    def __init__(
        self, 
        model: str, 
        color: str, 
        horse_power: int, 
        roof_state: str, 
        location: Number = 0
    ) -> None:
        if roof_state not in ['up', 'down']:
            raise ValueError('The roof parameter can be either up or down.')
        # super() refers to the parent class
        super().__init__(model, color, horse_power, location)  
        self.roof_state = roof_state